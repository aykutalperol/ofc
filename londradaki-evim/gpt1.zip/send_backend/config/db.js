

//aA103091992OFCADMIN

// config/db.js
const mysql = require('mysql2');

const db = mysql.createConnection({
  host: '92.205.0.157',
  user: 'OFCADMIN',
  password: 'aA103091992OFCADMIN',
  database: 'EMLAK_DB'
});

db.connect((err) => {
  if (err) {
    console.error('MySQL connection error: ', err);
  } else {
    console.log('MySQL connecteddd');
  }
});

module.exports = db;

